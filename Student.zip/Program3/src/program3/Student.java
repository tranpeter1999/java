/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package program3;

/**
 *
 * @author ptran88
 */
public class Student {
    private String studentName = "";
    private String SSN = "";
    private double GPA = 0.0;
    public Student(String studentName, String SSN, double GPA){
        this.studentName = studentName;
        this.SSN = SSN;
        this.GPA = GPA;
    }
    
    public String getName(){
        return this.studentName;
    }
    
    public String getSSN(){
        return this.SSN; //this is very unsecure...
    }
    
    public double getGPA(){
        return this.GPA;
    }
    
    public void setName(String studentName){
        this.studentName = studentName;
    }
    
    public void setSSN(String SSN){
        this.SSN = SSN;
    }
    
    public void setGPA(double GPA){
        this.GPA = GPA;
    }
    
    public String toString(){
        return "Student Name: " + this.studentName + "\nSSN: " + this.SSN + "\nGPA: " + this.GPA;
    }
    
    public boolean equals(Student other){
        return this.studentName == other.getName() && this.SSN == other.getSSN() && this.GPA == other.getGPA();
    }
}
