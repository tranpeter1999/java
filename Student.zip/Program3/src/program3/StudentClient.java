/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package program3;

/**
 *
 * @author ptran88
 */
public class StudentClient {
    public static void main(String[] args) {
        Student s1 = new Student("Joe Schmoe","123-45-6789",3.5);
        Student s2 = new Student("Jane Doe","987-65-4321",4.0);
        
        System.out.println(s1);
        System.out.println(s2);
        
        if(s1.equals(s2)){
            System.out.println("s1 and s2 are equal");
        }
        else{
            System.out.println("s1 and s2 are not equal");
        }
        
        s2.setName(s1.getName());
        s2.setSSN(s1.getSSN());
        s2.setGPA(s1.getGPA());
        
        if(s1.equals(s2)){
            System.out.println("s1 and s2 are equal");
        }
        else{
            System.out.println("s1 and s2 are not equal");
        }
    }
}
