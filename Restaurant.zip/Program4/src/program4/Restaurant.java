/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package program4;

/**
 *
 * @author ptran88
 */
public class Restaurant extends Store {
    int yearlyCustomers;
    double averagePrice;
    
    public Restaurant(String name, int yearlyCustomers, double averagePrice){
        super(name);
        this.yearlyCustomers = yearlyCustomers;
        this.averagePrice = averagePrice;
    }
    
    public int getYearlyCustomers(){
        return this.yearlyCustomers;
    }
    
    public double getAveragePrice(){
        return this.averagePrice;
    }
    
    public void setYearlyCustomers(int yearlyCustomers){
        if(yearlyCustomers < 0){
            System.out.println("Cannot set yearly customers to negative number");
        }
        else{
            this.yearlyCustomers = yearlyCustomers;
        }
    }
    
    public void setAveragePrice(double averagePrice){
        if(averagePrice < 0){
            System.out.println("Cannot set average price to negative number");
        }
        else{
            this.averagePrice = averagePrice;
        }
    }
    
    public double getAnnualTaxes(){
        return this.yearlyCustomers * this.averagePrice * this.taxRate;
    }
    
    public String toString(){
        return (super.toString() + "\nYearly Customers: " + this.yearlyCustomers + "\nAverage Dish Price: " + this.averagePrice);
    }
    
    public boolean equals(Restaurant other){
        return super.equals(other) && this.yearlyCustomers == other.getYearlyCustomers() && this.averagePrice == other.getAveragePrice();
    }
}
