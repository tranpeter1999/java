/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package program4;

/**
 *
 * @author ptran88
 */
public class Store {
    String storeName;
    double taxRate = 0.085;
    
    public Store(String storeName){
        this.storeName = storeName;
    }
    
    public String getName(){
        return this.storeName;
    }
    
    public void setName(String storeName){
        this.storeName = storeName;
    }
    
    public String toString(){
        return "Store Name: " + this.storeName + "\nTax Rate: " + this.taxRate;
    }
    
    public boolean equals(Store other){
        return this.storeName == other.getName();
    }
}
