/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package program4;

/**
 *
 * @author ptran88
 */
import java.text.DecimalFormat;

public class RestaurantClient {
    public static void main(String[] args) {
        Restaurant r1 = new Restaurant("Wendy's", 5000, 3.50);
        Restaurant r2 = new Restaurant("McDonald's", 4000, 3.95);
        
        System.out.println(r1);
        System.out.println(r2);
        
        r2.setYearlyCustomers(r1.getYearlyCustomers());
        r2.setAveragePrice(r1.getAveragePrice());
        
        if(r1.equals(r2)){
            System.out.println("r1 and r2 are equal");
        }
        else{
            System.out.println("r1 and r2 are not equal");
        }
        
        r2.setName(r1.getName());
        
        if(r1.equals(r2)){
            System.out.println("r1 and r2 are equal");
        }
        else{
            System.out.println("r1 and r2 are not equal");
        }
        
        DecimalFormat currFormat = new DecimalFormat("'$'###,###,###.00");
        
        System.out.println("r1 Taxes: " + currFormat.format(r1.getAnnualTaxes()));
    }
    
}
